import boto3
import csv
import json
import os
import pyodbc
from datetime import datetime

SECRET_NAME = os.environ.get('SECRET_NAME')
REGION_NAME = os.environ.get('REGION_NAME')
SERVER_NAME = os.environ.get('DB_SERVER')
DB_NAME = os.environ.get('DB_NAME')

s3_client = boto3.client('s3')
secrets_client = boto3.client(service_name='secretsmanager', region_name=REGION_NAME)

def lambda_handler(event, context):
    """
    Função principal da Lambda acionada por um evento S3.

    1. Extrai o nome do bucket e do arquivo do evento.
    2. Obtém as credenciais do banco de dados do AWS Secrets Manager.
    3. Baixa e lê o arquivo .csv do S3.
    4. Conecta-se ao banco de dados RDS SQL Server.
    5. Insere os dados do CSV na tabela 'Leads'.
    """
    print("Iniciando processamento do arquivo.")

    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        print(f"Bucket: {bucket_name}, Arquivo: {file_key}")
    except KeyError as e:
        print(f"Erro ao extrair informações do evento: {e}")
        return {'statusCode': 400, 'body': json.dumps('Formato de evento S3 inválido.')}

    if not file_key.lower().endswith('.csv'):
        print(f"O arquivo {file_key} não é um .csv e não será processado.")
        return {'statusCode': 200, 'body': json.dumps('Arquivo não-CSV ignorado.')}

    try:
        print("Buscando credenciais no Secrets Manager...")
        secret_value = secrets_client.get_secret_value(SecretId=SECRET_NAME)
        secret_data = json.loads(secret_value['SecretString'])
        db_user = secret_data['username']
        db_password = secret_data['password']
        print("Credenciais obtidas com sucesso.")

        print(f"Baixando arquivo {file_key} do bucket {bucket_name}...")
        s3_object = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        csv_content = s3_object['Body'].read().decode('utf-8').splitlines()
        csv_reader = csv.reader(csv_content)
        
        next(csv_reader, None)
        
        leads_data = list(csv_reader)
        print(f"Arquivo CSV lido. {len(leads_data)} registros encontrados.")

        connection_string = (
            f'DRIVER={{ODBC Driver 17 for SQL Server}};'
            f'SERVER={SERVER_NAME};'
            f'DATABASE={DB_NAME};'
            f'UID={db_user};'
            f'PWD={db_password};'
        )
        
        print("Conectando ao banco de dados RDS SQL Server...")
        with pyodbc.connect(connection_string, timeout=5) as conn:
            print("Conexão estabelecida com sucesso.")
            cursor = conn.cursor()

            print("Iniciando inserção dos dados na tabela 'Leads'...")
            for row in leads_data:
                if not row: continue
                
                name = row[0]
                email = row[1]
                submission_date = datetime.now()
                
                sql_insert = "INSERT INTO Leads (Name, Email, SubmissionDate) VALUES (?, ?, ?)"
                cursor.execute(sql_insert, name, email, submission_date)

            conn.commit()
            print(f"{len(leads_data)} registros inseridos com sucesso.")

        return {
            'statusCode': 200,
            'body': json.dumps(f'Sucesso! {len(leads_data)} registros do arquivo {file_key} foram processados.')
        }

    except Exception as e:
        print(f"ERRO: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps(f'Erro no processamento: {str(e)}')}